@extends('master.admin.master')
@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="card card-body">
                <table class="table table-bordered table-hover">
                    <tr>
                        <td>Subject Title</td>
                        <td>{{$subject->title}}</td>
                    </tr>
                    <tr>
                        <td>Subject Code</td>
                        <td>{{$subject->code}}</td>
                    </tr>
                    <tr>
                        <td>Subject Fee</td>
                        <td>{{$subject->fee}}</td>
                    </tr>
                    <tr>
                        <td>Short Description</td>
                        <td>{!!$subject->short_description !!}</td>
                    </tr>
                    <tr>
                        <td>Long Description</td>
                        <td>{!!$subject->long_description!!}</td>
                    </tr>
                    <tr>
                        <td>Trainer Name</td>
                        <td>{{$subject->teacher->name}}</td>
                    </tr>
                    <tr>
                        <td>Feature Image</td>
                        <td> <img src="{{asset($subject->image)}}" alt=""/></td>
                    </tr>
                </table>

            </div>
        </div>
    </div>

@endsection
