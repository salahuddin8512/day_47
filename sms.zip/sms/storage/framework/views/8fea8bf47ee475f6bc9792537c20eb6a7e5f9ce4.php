<?php $__env->startSection('body'); ?>
   <section class="py-5">
       <div class="container">
           <div class="row">
               <div class="col-md-3">
                   <div class="card">
                       <div class="list-group list-group-flush">
                           <a href="" class="list-group-item">My All Course</a>
                           <a href="<?php echo e(route('student-profile')); ?>" class="list-group-item">My Profile</a>
                           <a href="<?php echo e(route('change-password')); ?>" class="list-group-item">Change Password</a>
                           <a href="" class="list-group-item">My Payment</a>
                       </div>
                   </div>
               </div>
               <div class="col-md-9">
                    <div class="card">
                        <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                        <div class="card-header">My applied Recent Course</div>
                        <div class="body">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Course Title</th>
                                        <th>Trainer Name</th>
                                        <th>Course Fee</th>
                                        <th>Enroll Now</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php $__currentLoopData = $enrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($enroll->subject->title); ?></td>
                                        <td><?php echo e(\App\Models\Teacher::find($enroll->subject->teacher_id)->name); ?></td>
                                        <td><?php echo e($enroll->subject->fee); ?></td>
                                        <td><?php echo e($enroll->enroll_status); ?></td>
                                    </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
               </div>
           </div>
       </div>
   </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/student/home/home.blade.php ENDPATH**/ ?>