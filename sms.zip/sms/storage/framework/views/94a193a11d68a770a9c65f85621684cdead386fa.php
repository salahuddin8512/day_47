<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Manage Teacher Courser</h4>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover mb-0">
                            <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Course Title</th>
                                <th>Course Fee</th>
                                <th>Trainer Name</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($subject->title); ?></td>
                                    <td><?php echo e($subject->fee); ?></td>
                                    <td><?php echo e($subject->teacher->name); ?></td>
                                    <td><?php echo e($subject->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('view-detail', ['id' =>$subject->id])); ?>" class="btn btn-success btn-sm">
                                            <i class="fa fa-book-open"></i></a>
                                        <a href="<?php echo e(route('update-status', ['id' =>$subject->id])); ?>" class="btn <?php echo e($subject->status ==1 ?'btn-info': 'btn-warning'); ?> btn-sm">

                                            <i class="<?php echo e($subject->status ==1 ?'fa fa-arrow-up': 'fa fa-arrow-down'); ?>"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/admin/course/manage.blade.php ENDPATH**/ ?>