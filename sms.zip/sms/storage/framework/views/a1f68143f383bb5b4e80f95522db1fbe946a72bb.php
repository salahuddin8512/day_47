<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-body">
                <table class="table table-bordered table-hover">
                    <tr>
                        <td>Subject Title</td>
                        <td><?php echo e($subject->title); ?></td>
                    </tr>
                    <tr>
                        <td>Subject Code</td>
                        <td><?php echo e($subject->code); ?></td>
                    </tr>
                    <tr>
                        <td>Subject Fee</td>
                        <td><?php echo e($subject->fee); ?></td>
                    </tr>
                    <tr>
                        <td>Short Description</td>
                        <td><?php echo $subject->short_description; ?></td>
                    </tr>
                    <tr>
                        <td>Long Description</td>
                        <td><?php echo $subject->long_description; ?></td>
                    </tr>
                    <tr>
                        <td>Trainer Name</td>
                        <td><?php echo e($subject->teacher->name); ?></td>
                    </tr>
                    <tr>
                        <td>Feature Image</td>
                        <td> <img src="<?php echo e(asset($subject->image)); ?>" alt=""/></td>
                    </tr>
                </table>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/admin/course/detail.blade.php ENDPATH**/ ?>