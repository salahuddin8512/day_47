<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Congratulation Mr. <?php echo e($data['name']); ?>, Your Course registration successfully complete.</h1>
    <h3>Your login credential is given Bellow:</h3>
    <p>User Id: <?php echo e($data['user_id']); ?></p>
    <p>password: <?php echo e($data['password']); ?></p>
    <P>Thank You</P>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\sms\resources\views/email/course-enroll.blade.php ENDPATH**/ ?>