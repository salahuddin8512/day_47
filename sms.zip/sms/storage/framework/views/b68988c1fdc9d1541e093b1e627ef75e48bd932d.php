<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Manage Student</h4>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover mb-0">
                            <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Full Name</th>
                                <th>Student ID</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($student->name); ?></td>
                                    <td><?php echo e($student->id); ?></td>
                                    <td><?php echo e($student->email); ?></td>
                                    <td><?php echo e($student->mobile); ?></td>
                                    <td><?php echo e($student->status==1 ? 'Active' : 'Inactive'); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('student-status', ['id' => $student->id])); ?>" class="btn <?php echo e($student->status==1 ? 'btn-success' : 'btn-warning'); ?> btn-sm">
                                            <i class="fa fa-upload"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/admin/student/manage.blade.php ENDPATH**/ ?>